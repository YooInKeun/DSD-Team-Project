#ifndef PPD_H
#define PPD_H

#include <QWidget>
#include <QPushButton>
#include <QTableWidget>
#include <QTableWidgetItem>
#include <QVBoxLayout>

class ppd : public QWidget
{
    Q_OBJECT
public:
    explicit ppd(QWidget *parent = nullptr);

signals:

public slots:
    void buttonclose();
private:
    void creattable();

    QVBoxLayout *layoutp;
    QPushButton *pbc;
    QTableWidget *table;
};

#endif // PPD_H
