#include"Classroom.h"
#include<iostream>

Classroom::Classroom() {}

Classroom::Classroom(string name) {
    this->name = name;
    for (int i = 0; i < 6; i++) {
        for (int k = 0; k < 60; k++) {
            up[i][k] = 0;
            down[i][k] = 0;
        }
    }
}

/*void Classroom::printUpTable() {

    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < 60; j++) {

            /*if (up[i][j] < 10) {
            cout << "0";
            }

            cout <<"["<<i<<"]"<<"["<<j<<"]: "<< up[i][j] << " ";
        }
        cout << endl;
    }
}

void Classroom::printDownTable() {

    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < 60; j++) {

            /*if (up[i][j] < 10) {
            cout << "0";
            }

            cout << "[" << i << "]" << "[" << j << "]: " << down[i][j] << " ";
        }
        cout << endl;
    }
}*/
