#include "popup.h"

popup::popup(QDialog *parent) : QDialog(parent)
{
    pbc = new QPushButton("close", this);
    connect(pbc, &QAbstractButton::clicked, this, &popup::closebutton);
}

popup::~popup()
{
    delete pbc;
}

void popup::closebutton()
{
    close();
}
