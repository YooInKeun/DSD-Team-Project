#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    //this->setFixedSize(1024, 768);
    graph = new MyGraph;

    QWidget *page1 = new QWidget;
    QWidget *page2 = new QWidget;
    QWidget *leftside = new QWidget;
    QWidget *rightside = new QWidget;
    tab = new QTabWidget();
    layout = new QVBoxLayout(this);
    layout1 = new QHBoxLayout(this);
    layout2 = new QHBoxLayout(this);
    layout3 = new QHBoxLayout(this);
    layout4 = new QHBoxLayout;
    layout5 = new QVBoxLayout(this);
    mainlayout = new QHBoxLayout(this);
    imagelayout = new QVBoxLayout(this);
    secondlayout = new QVBoxLayout;
    maplayout = new QHBoxLayout;
    proplayout = new QVBoxLayout;
    pb1 = new QPushButton("Calc.");
    pb2 = new QPushButton("Calc.");
    debuggingtext = new QLabel("selected day");
    map1 = new QLabel;
    map2 = new QLabel;
    painter1 = new QPainter;
    painter2 = new QPainter;
    testpainter = new QPainter;

    creatTime();
    creatComp();
    creatLine();
    creatCombo();
    creatImage();
    creatTree();



    layout1->addWidget(new QLabel("Time"));
    layout1->addWidget(combo);
    layout1->addWidget(timeedit);
    layout2->addWidget(new QLabel("From"));
    layout2->addWidget(from);
    layout3->addWidget(new QLabel("To"));
    layout3->addWidget(dest);
    layout4->addWidget(new QLabel("Take time: "));
    layout4->addWidget(take);
    layout5->addWidget(new QLabel("Path"));
    layout5->addWidget(path);
    layout->addLayout(layout1);
    layout->addLayout(layout2);
    layout->addLayout(layout3);
    layout->addLayout(layout4);
    layout->addLayout(layout5);
    layout->addWidget(pb1);
    //layout->addWidget(debuggingtext);
    leftside->setLayout(layout);
    rightside->setLayout(imagelayout);
    //mainlayout->addLayout(imagelayout);
    //mainlayout->addLayout(layout);
    mainlayout->addWidget(rightside);
    mainlayout->addWidget(leftside);
    page1->setLayout(mainlayout);

    maplayout->addLayout(proplayout);
    secondlayout->addLayout(maplayout);
    secondlayout->addWidget(pb2);
    page2->setLayout(secondlayout);

    tab->addTab(page1, "MODE 1");
    tab->addTab(page2, "MODE 2");
    this->setCentralWidget(tab);

    testpainter->begin(page1);

    connect(combo, &QComboBox::currentTextChanged, this, &MainWindow::comboboxchange);
    connect(pb1, &QAbstractButton::clicked, this, &MainWindow::stateupdate);
    connect(pb2, &QAbstractButton::clicked, this, &MainWindow::makepopup);
    connect(timeedit, &QTimeEdit::timeChanged, this, &MainWindow::timechanged);
    connect(from, &QLineEdit::textChanged, this, &MainWindow::mapchange);
    connect(dest, &QLineEdit::textChanged, this, &MainWindow::mapchange);
}

MainWindow::~MainWindow()
{

}

void MainWindow::comboboxchange()
{
    int cur = combo->currentIndex();
    dayselected = cur;
}

void MainWindow::stateupdate()
{
    path->clear();
    path_print.clear();
    int timeselected;
    /*int ftempx = 0, ftempy = 0;
    int fcurx = 0, fcury = 0;
    int dtempx = 0, dtempy = 0;
    int dcurx = 0, dcury = 0;
    pair<float, float> tempco;*/
    //cout<<"I will find a class room "<<from->text().toUtf8().constData()<<" and "<<dest->text().toUtf8().constData()<<endl;

    string fromcross = graph->findroom(from->text().toUtf8().constData());
    string destcross = graph->findroom(dest->text().toUtf8().constData());

    graph->setDay(dayselected);
    timeselected = (selecttime.hour() - 8) * 4 + selecttime.minute()/15;
    graph->setTime(timeselected);

    float temp = 0.0f;
    if(fromcross == "ERR" || destcross == "ERR") path->setText("ERROR!!!");
    else {
        cout<<fromcross<<destcross<<dayselected<<timeselected<<endl;
        temp = graph->Dijkstra(fromcross, destcross, path_print);
        cout<<"Dijkstra end"<<endl;

        for(vector<string>::reverse_iterator iter = path_print.rbegin(); iter != path_print.rend(); ++iter)
            path->append("-> "+QString::fromStdString(*iter));
        /*for(vector<string>::reverse_iterator iter = path_print.rbegin(); iter != path_print.rend(); ++iter){
            if(graph->getCNode(*iter).getFloor() == fromfloor) {
                tempco = graph->getCNode(*iter).getCood();
                fcurx = (int)tempco.first;
                fcury = (int)tempco.second;
                if(ftempx == 0 && ftempy == 0) {
                    ftempx = fcurx;
                    ftempy = fcury;
                }
                else{
                    painter1->drawLine(fcurx, fcury, ftempx, ftempy);
                }
            }
            if(graph->getCNode(*iter).getFloor() == destfloor) {
                tempco = graph->getCNode(*iter).getCood();
                dcurx = (int)tempco.first;
                dcury = (int)tempco.second;
                if(dtempx == 0 && dtempy == 0) {
                    dtempx = dcurx;
                    dtempy = dcury;
                }
                else{
                    painter2->drawLine(dcurx, dcury, dtempx, dtempy);
                }
            }
        }*/
        testpainter->drawLine(0,0, 50, 50);

    }
    take->setText(QString::number((double)temp/60) + "min.");
    //take->setText("0");
    //path->setText("TEST");
}

void MainWindow::makepopup()
{
    newpopup= new ppd();
    newpopup->show();
}

void MainWindow::timechanged()
{
    selecttime = timeedit->time();
}

void MainWindow::mapchange()
{
    QString temp;
    if(!from->text().isEmpty()){
        temp = from->text();
        fromfloor = temp[0];
        if(fromfloor.isDigit() && temp.length() == 4){
            map1->setPixmap(mapbuf[fromfloor.digitValue()+15]);
        }
        else if(fromfloor.isDigit())
            map1->setPixmap(mapbuf[fromfloor.digitValue()+5]);
        else if(fromfloor=='B'){
            fromfloor = temp[1];
            map1->setPixmap(mapbuf[6-fromfloor.digitValue()]);
        }
    }
    if(!dest->text().isEmpty()){
        temp = dest->text();
        destfloor = temp[0];
        if(destfloor.isDigit() && temp.length() == 4){
            map2->setPixmap(mapbuf[destfloor.digitValue()+15]);
        }
        else if(destfloor.isDigit())
            map2->setPixmap(mapbuf[destfloor.digitValue()+5]);
        else if(destfloor=='B'){
            destfloor = temp[1];
            map2->setPixmap(mapbuf[6-destfloor.digitValue()]);
        }
    }
}

void MainWindow::creatTime()
{
    timeedit = new QTimeEdit();
    timeedit->setMinimumTime(QTime(8, 0));
    selecttime=QTime(9,0);
}

void MainWindow::creatComp()
{
    vector <string> temp = graph->getclassroomlist();
    for(vector<string>::iterator iter = temp.begin(); iter != temp.end(); iter++)
        complist.push_back(iter->data());
    compModel = new QStringListModel(complist);
    comp = new QCompleter;
    comp->setModel(compModel);
}

void MainWindow::creatLine()
{
    from = new QLineEdit;
    dest = new QLineEdit;
    path = new QTextBrowser;
    take = new QLineEdit;
    from->setCompleter(comp);
    dest->setCompleter(comp);
    path->setReadOnly(true);
    take->setReadOnly(true);
    path->setFixedSize(300, 500);
}
void MainWindow::creatCombo()
{
    combo = new QComboBox;

    combo->addItem("Mon.");
    combo->addItem("Tue.");
    combo->addItem("Wed.");
    combo->addItem("Thu.");
    combo->addItem("Fri.");
    combo->addItem("Sat.");

    dayselected = 0;
    //combo->addItem("Sun.");
}

void MainWindow::creatImage()
{
    QImage img("C:/Users/Lodjur/Pictures/Lp5Slgfp_400x400.jpg");
    QImage map;
    QMatrix rot;
    rot.rotate(270);
    for(int i = 0; i < 18; i++){
        if(i < 6)
            map.load(QString("C:/Users/Lodjur/Documents/dsd4/res/mapb")+QString::number(6-i)+QString("f.jpg"));
        else
            map.load(QString("C:/Users/Lodjur/Documents/dsd4/res/map")+QString::number(i-5)+QString("f.jpg"));
        map = map.scaledToWidth(400);
        map = map.transformed(rot);
        mapbuf[i] = QPixmap::fromImage(map);
    }
    img = img.scaledToWidth(400);
    QPixmap buf = QPixmap::fromImage(img);

    QLabel *tempmap = new QLabel;
    map1->setPixmap(buf);
    //tempimg1->resize(buf.width(), buf.height());
    map2->setPixmap(buf);
    //tempimg2->resize(buf.width(), buf.height());
    tempmap->setPixmap(buf);
    //tempmap->resize(buf.width(), buf.height());
    imagelayout->addWidget(map1);
    imagelayout->addWidget(map2);
    maplayout->addWidget(tempmap);
    painter1->begin(map1);
    painter2->begin(map2);
}

void MainWindow::creatTree()
{
    QLineEdit *nameedit = new QLineEdit;
    nameedit->setFrame(false);
    QLineEdit *flooredit = new QLineEdit;
    flooredit->setFrame(false);
    QCheckBox *staircheck = new QCheckBox;
    QCheckBox *elvcheck = new QCheckBox;
    QCheckBox **movablecheck = new QCheckBox *[18];
    for(int i = 0; i < 18; i++)
        movablecheck[i] = new QCheckBox;
    proptree = new QTreeWidget;
    proptree->setColumnCount(2);
    QTreeWidgetItem *headerItem = new QTreeWidgetItem;
    QTreeWidgetItem **nowItem = new QTreeWidgetItem*[5];
    for(int i = 0; i < 5; i++)
        nowItem[i] = new QTreeWidgetItem;
    headerItem->setText(0, "Node");
    headerItem->setText(1, "value");
    nowItem[0]->setText(0, "name");
    nowItem[1]->setText(0, "floor");
    nowItem[2]->setText(0, "isStair");
    nowItem[3]->setText(0, "isElv");
    nowItem[4]->setText(0, "movable");
    for(int i = 0; i < 5; i++)
        proptree->addTopLevelItem(nowItem[i]);
    proptree->setItemWidget(nowItem[0], 1, nameedit);
    proptree->setItemWidget(nowItem[1], 1, flooredit);
    proptree->setItemWidget(nowItem[2], 1, staircheck);
    proptree->setItemWidget(nowItem[3], 1, elvcheck);
    for(int i = 0; i< 18; i++) {
        nowItem[4]->addChild(new QTreeWidgetItem);
        if(i<6) nowItem[4]->child(i)->setText(0, "B"+QString::number(6-i));
        else nowItem[4]->child(i)->setText(0, QString::number(i-5));
        proptree->setItemWidget(nowItem[4]->child(i), 1, movablecheck[i]);
    }
    proptree->setHeaderItem(headerItem);
    proplayout->addWidget(proptree);
}

void MainWindow::treeHandler()
{

}

