#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QStringList>
#include <QStringListModel>
//#include <QSpinBox>
#include <QLineEdit>
#include <QCompleter>
#include <QTabWidget>
#include <QPushButton>
#include <QTimeEdit>
#include <QComboBox>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QWidget>
#include <QImage>
#include <QPixmap>
#include <QTabWidget>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include "ppd.h"
#include <QCheckBox>
#include <QMatrix>
#include <QDebug>
#include "classroom.h"
#include "cnode.h"
#include "mygraph.h"
#include "csvrow.h"
#include <QTextBrowser>
#include <QPainter>

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();
public slots:
    void comboboxchange();
    void stateupdate();
    void makepopup();
    void timechanged();
    void mapchange();
private:
    //void creatSpinbox();
    void creatTime();
    void creatComp();
    void creatLine();
    void creatCombo();
    void creatImage();
    void creatTree();
    void treeHandler();

    QTimeEdit *timeedit;
    //QSpinBox *spinbox;
    QLineEdit *from;
    QLineEdit *dest;
    QTextBrowser *path;
    QLineEdit *take;
    QCompleter *comp;
    QStringList complist;
    //QStringList dayList;
    QStringListModel *compModel;
    QComboBox *combo;
    QComboBox *floorselect;
    QVBoxLayout *layout;
    QHBoxLayout *layout1;
    QHBoxLayout *layout2;
    QHBoxLayout *layout3;
    QHBoxLayout *layout4;
    QVBoxLayout *layout5;
    QHBoxLayout *mainlayout;
    QVBoxLayout *secondlayout;
    QVBoxLayout *imagelayout;
    QVBoxLayout *proplayout;
    QHBoxLayout *maplayout;
    QTabWidget *tab;
    QPushButton *pb1;
    QPushButton *pb2;
    QLabel *debuggingtext;
    QTreeWidget *proptree;
    QLabel *map1;
    QLabel *map2;
    QLabel *map3;
    QPainter *painter1;
    QPainter *painter2;
    QPainter *testpainter;

    int dayselected;    //1:mon, ..., 7:sun
    QTime selecttime;
    vector<string> path_print;
    QChar fromfloor, destfloor;


    QPixmap mapbuf[18];

    ppd *newpopup;

    MyGraph *graph;
};

#endif // MAINWINDOW_H
