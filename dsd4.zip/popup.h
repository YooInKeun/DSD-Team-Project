#ifndef POPUP_H
#define POPUP_H

#include <QWidget>
#include <QPushButton>
#include <QDialog>

class popup : public QDialog
{
    Q_OBJECT
public:
    popup(QDialog *parent);
    ~popup();

signals:

public slots:
    void closebutton();
private:
    QPushButton *pbc;
};

#endif // POPUP_H
