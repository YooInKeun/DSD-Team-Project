#include "ppd.h"

ppd::ppd(QWidget *parent) : QWidget(parent)
{
    this->setFixedSize(1024, 768);
    creattable();

    layoutp = new QVBoxLayout;
    pbc = new QPushButton("Close", this);
    connect(pbc, &QAbstractButton::clicked, this, &ppd::buttonclose);

    layoutp->addWidget(table);
    layoutp->addWidget(pbc);
    this->setLayout(layoutp);
}

void ppd::buttonclose()
{
    close();
}

void ppd::creattable()
{
    QString tempstring;

    table = new QTableWidget(this);
    table->setGeometry(10, 10, 1004, 748);
    table->setColumnCount(2);
    table->setRowCount(2);
    for(int i = 0; i<2;i++){
        for(int j = 0; j<2; j++){
            tempstring.clear();
            tempstring = QString::number(i+1) + ", " + QString::number(j+1);
            table->setItem(i, j, new QTableWidgetItem(tempstring));
        }
    }
}
